<!doctype html>
<html>
<body style="font-family: Arial, sans-serif; color: #111827; line-height: 1.5;">
    <h2>New Contact Form Message</h2>

    <p><strong>Name:</strong> <?php echo e($contact['name']); ?></p>
    <p><strong>Email:</strong> <?php echo e($contact['email']); ?></p>
    <p><strong>Subject:</strong> <?php echo e($contact['subject']); ?></p>

    <p><strong>Message:</strong></p>
    <p><?php echo e($contact['message'] ?: 'No message provided.'); ?></p>
</body>
</html>
<?php /**PATH D:\All project\shabdd_technology\laravel-backend\resources\views/emails/contact.blade.php ENDPATH**/ ?>